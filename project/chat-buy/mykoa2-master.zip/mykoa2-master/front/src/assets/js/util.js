const baseUrl = "http://192.168.100.51:3000/"

export default {
    baseUrl
}