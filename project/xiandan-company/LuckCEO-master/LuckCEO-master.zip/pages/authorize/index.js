// pages/authorize/index.js
const qcloud = require('../../vendor/wafer2-client-sdk/index')
const config = require('../../config.js')
const util = require('../../utils/util.js')

Page({

  /**
   * 组件的初始数据
   */
  data: {

  },

  onLoad: function (options) {
      this.token = options.token
  },

  onAccpet: function () {
    wx.showLoading({
      title: '请求中...',
    })
    qcloud.request({
      url: config.service.answerLogin,
      data: {
        token: this.token,
        accept: 1
      },
      login: true,
      method: 'GET',
      success: (result) => {
        wx.hideLoading()
        if (result.statusCode != 200) {
          util.showModel('错误', result.data)
          return;
        }
        if (result.data.code == 0) {
          util.showSuccess('已登录')
          wx.redirectTo({
            url: '/pages/index/index',
          })
        } else {
          util.showModel('错误', result.data.error)
        }
      },
      fail: e => {
        wx.hideLoading()
        util.showModel('错误', e.errMsg)
      }
    })
  },
  onDeny: function () {
    wx.showLoading({
      title: '请求中...',
    })
    qcloud.request({
      url: config.service.answerLogin,
      data: {
        token: this.token,
        accept: 0
      },
      login: true,
      method: 'GET',
      success: (result) => {
        wx.hideLoading()
        if (result.statusCode != 200) {
          util.showModel('错误', result.data)
          return;
        }
        if (result.data.code == 0) {
          util.showSuccess('已拒绝')
          wx.redirectTo({
            url: '/pages/index/index',
          })
        } else {
          util.showModel('错误', result.data.error)
        }
      },
      fail: e => {
        wx.hideLoading()
        util.showModel('错误', e.errMsg)
      }
    })
  }
})