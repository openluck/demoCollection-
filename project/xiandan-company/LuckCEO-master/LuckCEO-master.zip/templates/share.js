var page,onShareCallback

var showShare = isShow=>{
  page.setData({ 'share.isShowShare': isShow})
}

var onClose = () =>{
  page.setData({ 'share.isShowShare': false })
}

var onShare = () => {
  if (onShareCallback){
    onShareCallback()
  }
}

var init = (p,callback)=>{
  onShareCallback = callback
  page = p
  page.onShareClose = onClose
  page.onShare = onShare
}

module.exports = { init, showShare}