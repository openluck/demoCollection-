
var mPage, mSuccess, mFail

var onGotUserInfo = e => {
  mPage.setData({
    'login.isShow': false
  })
  if (e.detail.userInfo) {
    mSuccess(e.detail)
  } else {
    mFail('cancel')
  }
}

var onCancel = () => {
  mPage.setData({
    'login.isShow': false
  })
  mFail('cancel')

}

var init = page => {
  if (mPage!= null){
    hidden(mPage)
  }

  mPage = page
  mPage.onGotUserInfo = onGotUserInfo
  mPage.onLoginCancel = onCancel
}

var show = (page,success, fail) => {
  init(page)
  mSuccess = success
  mFail = fail
  mPage.setData({
    'login.isShow': true
  })
}

var hidden = (page) => {
  page.setData({
    'login.isShow': false
  })
}

var isShow = (page) => {

  var login = page.data['login']

  return login && login['isShow'] === true
}



module.exports = {
  show,
  hidden,
  isShow
}